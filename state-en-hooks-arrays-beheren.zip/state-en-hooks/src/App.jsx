import Counter from "./Counter";
import Login from "./Login";
import Todos from "./Todos";
import Deelnemers from "./Deelnemers";

export default function App() {
  return (
    <div>
      {/* <Counter /> */}
      {/* <Login /> */}
      {/* <Todos /> */}
      <Deelnemers />
    </div>
  );
}
