function ProductItem() {
  return (
    <div>
      <h2>Idris Dildo</h2>
      <p>Price: 666€</p>
      <p>In Stock</p>
    </div>
  );
}

export default ProductItem;
