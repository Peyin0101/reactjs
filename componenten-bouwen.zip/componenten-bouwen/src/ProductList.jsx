import ProductItem from "./ProductItem";

function ProductList() {
  return (
    <div>
      <h1>Product List</h1>
      <ProductItem />
      <ProductItem />
      <ProductItem />
      <ProductItem />
    </div>
  );
}

export default ProductList;
