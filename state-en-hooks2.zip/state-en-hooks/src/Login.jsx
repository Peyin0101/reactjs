import { useState } from "react";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  let isFormValid = username.length > 0 && password.length > 0;

  const submit = () => alert("Login succesfull!");

  return (
    <div className="container">
      <h1>Login</h1>
      <div>
        <label htmlFor="username">Username</label>
        <input
          className="username"
          type="text"
          id="username"
          name="username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
      </div>
      <div>
        <label htmlFor="password">Password</label>
        <input
          className="password"
          type="password"
          id="password"
          name="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <button onClick={submit} disabled={!isFormValid}>
        Login
      </button>
    </div>
  );
}
