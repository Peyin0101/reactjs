import Counter from "./CounterStart";

function App() {
  return (
    <>
      <Counter />
    </>
  );
}

export default App;
