import { useState } from "react";
import ToggleSwitch from "./ToggleSwitchStart";

function App() {
  return (
    <div>
      <ToggleSwitch />
    </div>
  );
}

export default App;
