import { useState } from "react";
import RecipesPage from "./RecipesPageStart";

function App() {
  return (
    <>
      <RecipesPage />
    </>
  );
}

export default App;
