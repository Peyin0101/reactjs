import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import ControlledInputsStart from "./ControlledInputsStart";
import "./App.css";

function App() {
  return (
    <>
      <div>
        <ControlledInputsStart />
      </div>
    </>
  );
}

export default App;
