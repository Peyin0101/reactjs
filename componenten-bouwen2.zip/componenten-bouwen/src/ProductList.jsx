import ProductItem from "./ProductItem";

function ProductList() {
  return (
    <div>
      <ProductItem />
      <ProductItem />
      <ProductItem />
      <ProductItem />
    </div>
  );
}

export default ProductList;
